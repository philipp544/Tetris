package main;

public class Language {

	public static boolean language = true;
	
	public static String translateNext() {		//translation for the ingame words
		if(language == true) {
			return "Next";
		} else {
			return "Nächste";
		}
	}
	
	public static String translateLines() {
		if(language == true) {
			return "Lines";
		} else {
			return "Linien";
		}
	}
	
	public static String translateScore() {
		if(language == true) {
			return "Score";
		} else {
			return "Punktzahl";
		}
	}

	public static String translateLevel() {
		if(language == true) {
			return "Level";
		} else {
			return "Stufe";
		}
	}
	public static String translateGameOver() {
		if(language == true) {
			return "Game Over";
		} else {
			return "Spiel vorbei";
		}
	}
	public static String translatePaused() {
		if(language == true) {
			return "Paused";
		} else {
			return "Pausiert";
		}
	}

	public boolean isLanguage() {
		return language;
	}

	public void setLanguage(boolean language) {
		Language.language = language;
	}
}