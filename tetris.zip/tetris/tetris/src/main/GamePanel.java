package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;
public class GamePanel extends JPanel implements Runnable {

    /**gameloop
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final int WIDTH = 1280;
    public static final int HEIGHT = 720;
    final int FPS = 60;
    Thread gameThread;
    PlayManager pm;
    private PlayManager playManager;
    
    private GameMenu gameMenu;
    private boolean menuOpen;

    private String language;

    public GamePanel() {										   // Constructor of the GamePanel class 
        // Panel Settings
        this.setPreferredSize(new Dimension(WIDTH, HEIGHT));	
        this.setBackground(Color.black);
        this.setLayout(null);
        // implement KeyListener
        this.addKeyListener(new KeyHandler());		// adding new keylistener 
        this.setFocusable(true);					// set panel focusable to be able to receive keyboard input 

        pm = new PlayManager();						// new instance of PlayManager for the game logic		
        gameMenu = new GameMenu();
        gameMenu.setVisible(false);					// set the menu invisible 
        menuOpen = false;
        playManager = new PlayManager();
    }
    public PlayManager getPlayManager() {
        return playManager;
    }
    public void launchGame() {						// start the game, create a new thread 
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run() {								//Gameengine for Tetris
        // Game Loop
        double drawInterval = 1000000000 / FPS;		// 16.67 milliseconds
        double delta = 0;							// saves the time between the updates 
        long lastTime = System.nanoTime();			// saves the actual time in nanosec. 
        long currentTime;

        while (gameThread != null) {				// continues as long as gameThread is not null 
            currentTime = System.nanoTime();		// updates the time in nanoseconds
            delta += (currentTime - lastTime) / drawInterval; //Calculates the elapsed time since the last update and adds delta to it
            lastTime = currentTime;		// updates lastTime to currentTime

            if (delta >= 1) {
                update();
                repaint();
                delta--;				
            }
        }
    }

    private void update() {
        if (!KeyHandler.pausePressed && !pm.gameOver) {
            pm.update();
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        pm.draw(g2, language);

        if (KeyHandler.pausePressed && !menuOpen) {
            gameMenu.setVisible(true);
            menuOpen = true;
        } else if (!KeyHandler.pausePressed && menuOpen) {
            gameMenu.setVisible(false);
            menuOpen = false;
        }
    }
}

