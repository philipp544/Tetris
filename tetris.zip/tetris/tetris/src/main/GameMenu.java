package main;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameMenu extends JDialog {
    /**Game Menu, import for most of the functions
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton englishButton;
    private JButton germanButton;
    private JButton showhighscores;
    private JButton savescore;
    private JButton quitButton;
    private JButton sortarrayButton;
    private JButton toStringButton; 
    private JButton factsButton;				// Array appropriate for the bilingual gui 
    private static final String[] GERMAN_TEXTS = {"Englisch", "Deutsch", "Bestenliste", "Punktzahl speichern", "Verlassen", "Array sortieren", "Spielstatistiken", "Allgemeines über Tetris"};
    private static final String[] ENGLISH_TEXTS = {"English", "German", "Leaderboard", "Save Score", "Quit", "Sort Array", "Game Stats", "General Knowledge"};
    
    private PlayManager playManager; 					//Instanzvariable vom Typ PlayManager
    
	public void setGamePanel(GamePanel gamePanel ) {		
        
    }
    
    public void setPlayManager(PlayManager playManager) {
        this.playManager = playManager;
    }
    
    public GameMenu() {
        setTitle("Game Menu");				//set the game menu 
        setSize(300, 320);
        setLayout(new GridLayout(8, 1));

        englishButton = new JButton("English");
        englishButton.addActionListener(new ActionListener() {
            @Override
            
            public void actionPerformed(ActionEvent e) {	
                setTextsen(ENGLISH_TEXTS);
                Language.language=true;

            }
  
        });
        add(englishButton);

        germanButton = new JButton("German");
        germanButton.addActionListener(new ActionListener() {
            @Override
            
            public void actionPerformed(ActionEvent e) {
                setTextsde(GERMAN_TEXTS);
                Language.language=false;

             
            }
        });
        add(germanButton);
 
        showhighscores = new JButton("Leaderboard");
        showhighscores.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	
                     PlayManager.showhighscores();
                
                 
             }
        });
        add(showhighscores);

        savescore = new JButton("Save Score");
        PlayManager playManager = new PlayManager();
        savescore.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	
                  PlayManager.savescore(playManager);		
                 
            }
        });
        add(savescore);
        
        quitButton = new JButton("Quit");
        quitButton.addActionListener(new ActionListener() {
            @Override  
            public void actionPerformed(ActionEvent e) {	
            	System.exit(0);    
            }
  
        });
        add(quitButton);
        
        sortarrayButton = new JButton("sort array");
        sortarrayButton.addActionListener(new ActionListener() {
            @Override  
            public void actionPerformed(ActionEvent e) {	
            	
            	 Arraysortieren.sortAndPrintArray(ENGLISH_TEXTS);
            	 
            }
  
        });
        add(sortarrayButton);
        
        toStringButton = new JButton("Game Stats");
        toStringButton.addActionListener(new ActionListener() {
            @Override  
            public void actionPerformed(ActionEvent e) {	
            	
            	PlayManager playManager2 = new PlayManager();
				System.out.println(playManager2.toString());
            	 
            }
  
        });
        add(toStringButton);
        
        factsButton = new JButton("General Knowledge");
        
        factsButton.addActionListener(new ActionListener() {
            @Override  
            public void actionPerformed(ActionEvent e) {	
            
                GeneralKnowledge generalKnowledge = new GeneralKnowledge();
              
                    generalKnowledge.getVars().printoutfacts(generalKnowledge.tetris_publishing_date, generalKnowledge.programmer_of_tetris, generalKnowledge.Rechner_auf_dem_programmiert_wurde);
         
                
                
            }
        });
        add(factsButton);

        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private void setTextsde(String[] texts) {			//translation to german
    	englishButton.setText(texts[0]);
        germanButton.setText(texts[1]);
        showhighscores.setText(texts[2]);
        savescore.setText(texts[3]);
        quitButton.setText(texts[4]);
        sortarrayButton.setText(texts[5]);
        toStringButton.setText(texts[6]);
        factsButton.setText(texts[7]);

    }
    
    private void setTextsen(String[] texts) {			// translation to english 
    	englishButton.setText(texts[0]);
        germanButton.setText(texts[1]);
        showhighscores.setText(texts[2]);
        savescore.setText(texts[3]);
        quitButton.setText(texts[4]);
        sortarrayButton.setText(texts[5]);
        toStringButton.setText(texts[6]);
        factsButton.setText(texts[7]);

    }
}