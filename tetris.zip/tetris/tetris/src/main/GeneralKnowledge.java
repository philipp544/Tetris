package main;

public class GeneralKnowledge {
	public String tetris_publishing_date = "1984 is the Birthday of Tetris.\n";
	public String programmer_of_tetris = "Alexei Paschitnow programmed Tetris.\n";
	public String Rechner_auf_dem_programmiert_wurde = "Elektronika-60-Rechner was the Computer where Alexei Paschitnow programmed Tetris.\n";


    public abstract class variables {
        public abstract void printoutfacts(String tetris_publishing_date, String programmer_of_tetris, String Rechner_auf_dem_programmiert_wurde);   // abstract classes arent supposed to build objects, only for general characteristics 
       }

    private variables vars = new variables() {
        @Override
        public void printoutfacts(String tetris_publishing_date, String programmer_of_tetris, String Rechner_auf_dem_programmiert_wurde) {
                System.out.println(tetris_publishing_date + programmer_of_tetris + Rechner_auf_dem_programmiert_wurde);
        }
    };

	public variables getVars() {
		return vars;
	}

	public void setVars(variables vars) {
		this.vars = vars;
	}
}

