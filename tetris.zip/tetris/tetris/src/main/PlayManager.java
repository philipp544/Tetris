package main;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Pattern;

import org.junit.Test;

import mino.Block;
import mino.Mino;
import mino.Mino_Bar;
import mino.Mino_L1;
import mino.Mino_L2;
import mino.Mino_Square;
import mino.Mino_T;
import mino.Mino_Z1;
import mino.Mino_Z2;

public class PlayManager implements Serializable{  

    private static final long serialVersionUID = 1L;
	// Main Play Area 
	final int WIDTH = 360;
	final int HEIGHT = 600;
	public static int left_x;
	public static int right_x;
	public static int top_y;
	public static int bottom_y;
	
	//Mino
	Mino currentMino;
	int MINO_START_X;
	int MINO_START_Y;
	Mino nextMino;
	int NEXTMINO_X;
    int NEXTMINO_Y;
	public static ArrayList<Block> staticBlocks = new ArrayList<>(); //public ArrayList<Block> staticBlocks;
	
	// Others
	public static int dropInterval = 60;	// mino drops in every 60 frames
	boolean gameOver;
	
	// Effect
	boolean effectCounterOn;
	int effectCounter;
	ArrayList<Integer> effectY = new ArrayList<>(); //ArrayList<Integer> effectY;
	
	//Score
	int level = 1;
	int lines;
    int score;
	
	//gamestate
	File datei01 = new File("Bestenliste.txt");
	File datei03 = new File("C:\\Users\\test\\Documents\\uni\\java\\tetris\\tetris\\Bestenliste.txt");
	
/**
 * This is my Moduletest with JUnit
 */
	
	@Test
    public void testConstructor() {
        PlayManager playManager = new PlayManager();
        assertNotNull(playManager);					//is the playmanager object successfully created
        assertEquals(360, playManager.WIDTH);
        assertEquals(600, playManager.HEIGHT);
        assertEquals(460, playManager.left_x);
        assertEquals(820, playManager.right_x);
        assertEquals(50, playManager.bottom_y);
        assertEquals(650, playManager.top_y);
    }

    @Test
    public void testPickMino() {
        PlayManager playManager = new PlayManager();
        Mino mino = playManager.pickMino();
        assertNotNull(mino);
        assertTrue(mino instanceof Mino_L1 || mino instanceof Mino_L2 || mino instanceof Mino_Square || mino instanceof Mino_Bar || mino instanceof Mino_T || mino instanceof Mino_Z1 || mino instanceof Mino_Z2);	// is there a instance of a named class 
    }

    @Test
    public void testUpdate() {
        PlayManager playManager = new PlayManager();
        playManager.update();
        assertNotNull(playManager.currentMino);
        assertEquals(playManager.MINO_START_X, playManager.currentMino.b[0].x);
        assertEquals(playManager.MINO_START_Y, playManager.currentMino.b[0].y);
    }

    @Test
    public void testCheckDelete() {
        PlayManager playManager = new PlayManager();
        playManager.checkDelete();
        assertNotNull(playManager.staticBlocks);
        assertEquals(0, playManager.staticBlocks.size());
    }

    @Test
    public void testGetters() {
        PlayManager playManager = new PlayManager();
        assertEquals(1, playManager.getlevel());
        assertEquals(0, playManager.getlines());
        assertEquals(0, playManager.getscore());
        assertNotNull(playManager.getcurrentMino());
        assertEquals(playManager.MINO_START_X, playManager.getMINO_START_X());
        assertEquals(playManager.MINO_START_Y, playManager.getMINO_START_Y());
        assertNotNull(playManager.getnextMino());
        assertEquals(playManager.NEXTMINO_X, playManager.getNEXTMINO_X());
        assertEquals(playManager.NEXTMINO_Y, playManager.getNEXTMINO_Y());
        assertNotNull(playManager.getstaticBlocks());
    }

    @Test
    public void testSetters() {
        PlayManager playManager = new PlayManager();
        playManager.setlevel(2);
        assertEquals(2, playManager.getlevel());
        playManager.setlines(10);
        assertEquals(10, playManager.getlines());
        playManager.setscore(100);
        assertEquals(100, playManager.getscore());
        Mino mino = new Mino_L1();
        playManager.setcurrentMino(mino);
        assertEquals(mino, playManager.getcurrentMino());
        playManager.setnextMino(mino);
        assertEquals(mino, playManager.getcurrentMino());
    }

    @Test
    public void testGameLogic() {
        PlayManager playManager = new PlayManager();

        // Testfall 1: Mino bewegen
        Mino mino = playManager.pickMino();
        playManager.setcurrentMino(mino);
        playManager.update();
        assertEquals(playManager.MINO_START_X, playManager.currentMino.b[0].x);
        assertEquals(playManager.MINO_START_Y, playManager.currentMino.b[0].y);

        // Testfall 2: Zeile löschen
        playManager.checkDelete();
        assertEquals(0, playManager.staticBlocks.size());
        assertEquals(1, playManager.getlines());
        assertEquals(100, playManager.getscore());
    }
    private void setnextMino(Mino nextMino) {
		this.nextMino = nextMino;
		
	}

	private void setcurrentMino(Mino currentMino) {
		this.currentMino = currentMino;
	}

	private void setscore(int score) {
		this.score = score;
	}

	private void setlines(int lines) {
		
		this.lines = lines;
	}

	private void setlevel(int level) {
			this.level = level;
	}

	
	public PlayManager() {							
		
		// Main Play Area Frame
		left_x = (GamePanel.WIDTH/2) - (WIDTH/2); // 1280/2 - 360/2 = 460
		right_x = left_x + WIDTH;
		bottom_y = 50;
		top_y = bottom_y + HEIGHT;
		
		MINO_START_X = left_x + (WIDTH/2) - Block.SIZE;
		MINO_START_Y = bottom_y + Block.SIZE;  
		
		NEXTMINO_X = right_x + 175;
		NEXTMINO_Y = bottom_y + 500;				
		
		// Set the starting Mino
		currentMino = pickMino();
		currentMino.setXY(MINO_START_X, MINO_START_Y);
		nextMino = pickMino();
		nextMino.setXY(NEXTMINO_X, getNEXTMINO_Y());
		
		
		
	}
	private Mino pickMino() {
		
		//Pick a random mino
		Mino mino = null;
		int i = new Random().nextInt(7);
		
		switch(i) {
		case 0: mino = new Mino_L1();break;
		case 1: mino = new Mino_L2();break;
		case 2: mino = new Mino_Square();break;
		case 3: mino = new Mino_Bar();break;
		case 4: mino = new Mino_T();break;
		case 5: mino = new Mino_Z1();break;
		case 6: mino = new Mino_Z2();break;
		}
		return mino;
	}
	
	
	
	public void update() {
		
		// check if the current Mino is active 
		if(currentMino.active == false) {
			// if the mino is not active, put it into the staticBlocks
			staticBlocks.add(currentMino.b[0]);
			staticBlocks.add(currentMino.b[1]);
			staticBlocks.add(currentMino.b[2]);
			staticBlocks.add(currentMino.b[3]);
			
			// check if the game is over
			if(currentMino.b[0].x == MINO_START_X && currentMino.b[0].y == MINO_START_Y) {
				// this means the currentMino immediately collided a block and couldn't move at all
				// so it's xy are the same with the nextMino's
				gameOver = true;
				 savescore(this); // Save score when the game is over
			}
			currentMino.deactivating = false;
			
			// replace the current Mino with the nextMino
			currentMino = nextMino;
			currentMino.setXY(MINO_START_X, MINO_START_Y);
			nextMino = pickMino();
			nextMino.setXY(NEXTMINO_X, NEXTMINO_Y);
			
			// when a mino becomes inactive, check if lines can be deleted
			checkDelete();
		}
		else {
			currentMino.update();
		}
	}
	private void checkDelete() {
		
		
		int x = left_x;
		int y = bottom_y;
		int blockCount = 0;
		int lineCount = 0;
		
		while(x < right_x && y < top_y) {
			
			for(int i = 0; i < staticBlocks.size(); i++) {
				if(staticBlocks.get(i).x == x && staticBlocks.get(i).y == y) {
					// increase the count if there is a static block
					blockCount++;
				}
			}
			x += Block.SIZE;
			
			if(x == right_x) {
				
				// if the blockCount hits 12, that means the current y line is all filled with blocks 
				// so we can delete them
				if(blockCount == 12) {
					
					effectCounterOn = true;
					effectY.add(y);
					
					for(int i = staticBlocks.size()-1; i > -1; i--) {
						//remove all the blocks in the current y line
						if(staticBlocks.get(i).y == y) {
							staticBlocks.remove(i);
						}
					}
					
					lineCount++;
					lines++;
					// Drop Speed
					// if the line score hits a certain number, increase the drop speed
					// 1 is the fastest
					if(lines % 10 == 0 && dropInterval > 1) {
						
						level++;
						if(dropInterval > 10) {
							dropInterval -= 10;
						}
						else {
							dropInterval -= 1;
						}
					}
					
					
					// a line has been deleted so need to slide down blocks that are above it 
					for(int i = 0; i < staticBlocks.size(); i++) {
						// if a block is above the current y, move it down by the block size
						if(staticBlocks.get(i).y < y) {
							staticBlocks.get(i).y += Block.SIZE;
						}
					}
				}
				
				blockCount = 0;
				x = left_x;
				y += Block.SIZE;
			}
		}
		
		// Add Score
		if(lineCount > 0) {
			int singleLineScore = 10 * level;
			score += singleLineScore * lineCount;
		}
	}
	public void draw(Graphics2D g2, String language) {
		
	
		// Draw Play Area Frame
		g2.setColor(Color.white);
		g2.setStroke(new BasicStroke(4f));
		g2.drawRect(left_x-4, bottom_y-4, WIDTH+8, HEIGHT+8);
		
		// Draw Next Mino Frame 
		int x = right_x + 100;
		int y = top_y - 200;
		g2.drawRect(x, y, 200, 200);
		g2.setFont(new Font("Arial", Font.PLAIN, 30));
		g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		g2.drawString(Language.translateNext(), x+60, y+60);
		
		// Draw Score Frame
		g2.drawRect(x, bottom_y, 250, 300);
		x += 40;
		y = bottom_y + 90;
		g2.drawString(Language.translateLevel()+ " : " + level, x, y); y += 70;
		g2.drawString(Language.translateLines()+ " : " + lines, x, y); y += 70;
		g2.drawString(Language.translateScore()+ " : " + score, x, y); 
		
		// Draw the currentMino 
		
		if(currentMino != null) {
			currentMino.draw(g2);
		}
		// Draw next mino 
		nextMino.draw(g2);
		
		// Draw static blocks
		for(int i = 0; i < staticBlocks.size(); i++) {
			staticBlocks.get(i).draw(g2);
		}
		
		// draw effect
		if(effectCounterOn) {
			effectCounter ++;
			
			g2.setColor(Color.red);
			for(int i = 0; i < effectY.size(); i++) {
				g2.fillRect(left_x, effectY.get(i), WIDTH, Block.SIZE);
			}
			
			if(effectCounter == 10) {
				effectCounterOn = false;
				effectCounter = 0;
				effectY.clear();
			}
		}
		
		// draw pause or Game Over
		g2.setColor(Color.YELLOW);
		g2.setFont(g2.getFont().deriveFont(50f));
		if(gameOver) {
			x = left_x + 25;
			y = bottom_y + 320;
			g2.drawString(Language.translateGameOver(), x, y);
		}
		else if(KeyHandler.pausePressed) {
			x = left_x + 70;
			y = bottom_y + 320;
			g2.drawString(Language.translatePaused(), x, y);
		}
		// Draw the Game Title
		x = 35;
		y = bottom_y + 320;
		g2.setColor(Color.WHITE);
		g2.setFont(new Font("Times New Roman", Font.ITALIC, 60));
		g2.drawString("Better Tetris", x + 20, y);
		}

	public static Object getInstance() {
		
		return null;
	}
	public void setInstance(PlayManager pm) {
				
	}
	public int getlevel(){
		return level;
	}
	public int getlines(){
		return lines;
	}
	public int getscore(){
		return score;
	}
	public Mino getcurrentMino(){
		return currentMino;
	}
	public int getMINO_START_X(){
		return MINO_START_X;
	}
	public int getMINO_START_Y(){
		return MINO_START_Y;
	}
	public Mino getnextMino(){
		return nextMino;
	}
	public int getNEXTMINO_X(){
		return NEXTMINO_X;
	}
	public int getNEXTMINO_Y(){
		return NEXTMINO_Y;
	}
	public ArrayList<Block> getstaticBlocks(){
		return staticBlocks;
	}
	
    // load score
	public static void savescore(PlayManager playManager) {
	    Scanner scanner = new Scanner(System.in);
	    String name;
	    boolean validName = false;
	    
	    // Regular expression to check if the string contains any digits
	    Pattern pattern = Pattern.compile(".*\\d.*");
	    
	    
	    while (!validName) {
	        System.out.println("Geben Sie Ihren Namen ein:");
	        name = scanner.nextLine();
	
	 // Check if the name contains any digits
     if (pattern.matcher(name).matches()) {
         System.out.println("Fehler: Der Name darf keine Zahlen enthalten. Bitte versuchen Sie es erneut.");
     } else {
         validName = true;
         try {
        	 File datei = new File("C:\\Users\\test\\Documents\\uni\\java\\tetris\\tetris\\Bestenliste.txt");
        	 FileWriter writer = new FileWriter(datei, true);
        	 writer.write("\n" + name + " " + playManager.getscore());
             writer.flush();
	  } catch(IOException e) {
		  System.out.println("file could not be edited");
	  }
    }
  }
}
	 // save score
	 public static void showhighscores(){	 
	 		File datei = new File("C:\\Users\\test\\Documents\\uni\\java\\tetris\\tetris\\Bestenliste.txt");
	 		Scanner scan = null;
	 		try {
				scan = new Scanner(datei);
			} catch (FileNotFoundException e) {
				
				System.out.println("File not found");
			}
	 		while(scan.hasNext()) {
	 			System.out.println(scan.nextLine());
	 		}
	  }
	 	

	 @Override
	 public String toString() {
	     return "PlayManager{" +
	             "WIDTH=" + WIDTH +
	             ", HEIGHT=" + HEIGHT +
	             ", left_x=" + left_x +
	             ", right_x=" + right_x +
	             ", top_y=" + top_y +
	             ", bottom_y=" + bottom_y +
	             ", currentMino=" + currentMino +
	             ", nextMino=" + nextMino +
	             ", staticBlocks=" + staticBlocks +
	             ", dropInterval=" + dropInterval +
	             ", gameOver=" + gameOver +
	             ", level=" + level +
	             ", lines=" + lines +
	             ", score=" + score +
	             '}';
	     
	 		}
}
