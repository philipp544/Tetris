package main;

import java.util.Arrays;

public class Arraysortieren {
	 private static final String[] ENGLISH_TEXTS = {"English", "German", "Save Game", "Load Game", "Quit"};
	 
	  public static void übergeben(String[] args) {
	        sortAndPrintArray(ENGLISH_TEXTS);
	        }
	public static void sortAndPrintArray(String[] ENGLISH_TEXTS) {
		
		   // sort the array
        Arrays.sort(ENGLISH_TEXTS);		//iterative Timsort  

        // print out strings 
        for (String text : ENGLISH_TEXTS) {
            System.out.println(text);
        }
	}
}
