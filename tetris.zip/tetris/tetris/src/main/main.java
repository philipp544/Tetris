package main;
import javax.swing.JFrame;


/**
 * This is my main class 
 * Most of the Code is written in PlayManager class
 * @author Philipp Burkhardt s87197
 */

public class main {

	public static void main(String[] args) { // main class that starts the game

		  GameMenu gameMenu = new GameMenu(); 	// new GameMenu instance 
			
		JFrame window = new JFrame("Tetris");
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		//ending the program when hitting the cross 
		window.setResizable(false);									//window is not resizeable 
		
											// Add GamePanel to the window
        GamePanel gp = new GamePanel();
        
        gameMenu.setPlayManager(gp.getPlayManager()); // Set the PlayManager instance to GameMenu
        
      		
        gameMenu.setGamePanel(gp); // Set the GamePanel instance to GameMenu

        window.add(gp);
        window.pack(); // the size of the game panel = the size of the window

        window.setLocationRelativeTo(null);
        window.setVisible(true);

        gp.launchGame();
	}

}
